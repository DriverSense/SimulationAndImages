https://dataverse.vtti.vt.edu/dataset.xhtml?persistentId=doi:10.15787/VTT1/CEU6RB
Custer, Kenny, 2018, "100-Car Data", https://doi.org/10.15787/VTT1/CEU6RB, VTTI, V2 
@data{VTT1/CEU6RB_2018,
author = {Custer, Kenny},
publisher = {VTTI},
title = "{100-Car Data}",
year = {2018},
version = {V2},
doi = {10.15787/VTT1/CEU6RB},
url = {https://doi.org/10.15787/VTT1/CEU6RB}
}

