https://data.mendeley.com/datasets/jj3tw8kj6h/2
Yuksel, Asim; Atmaca, Şerafettin (2020), “Driving Behavior Dataset”, Mendeley Data, V2, doi: 10.17632/jj3tw8kj6h.2
